package ch06.exam.omok;

import java.util.Scanner;

public class Player {
    String name;
    String stone;
    boolean victory= false;
    
    Player(String name, String stone) {
        this.name = name;
        this.stone = stone;
    }
    

}

